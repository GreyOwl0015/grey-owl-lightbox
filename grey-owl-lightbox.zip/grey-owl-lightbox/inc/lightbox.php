<!-- lightbox block start -->
<section class="trigger-all-go-lightbox-blocks" style="display: none;" aria-hidden="true">
    <div class="blocks trigger-gol-blocks"></div>
</section>
<div class="go-lightbox-wrapper trigger-go-lightbox-wrapp" style="display: none;" aria-hidden="true" role="dialog">
    <div class="bg-btn-close trigger-bg-btn-close"></div>
    <div class="go-lightbox-block trigger-go-lightbox-block">

        <div class="media-block-wrapper trigger-media-block-wrapp">

            <div class="top-close-btn-wrapp trigger-tbtn-close-wrapp">
                <button type="button" class="top-close-lightbox trigger-top-close-lightbox" title="close lightbox" aria-label="close lightbox" tabindex="-1">
                    <?php esc_html_e('close lightbox', 'greyowl'); ?>
                </button>
            </div>

            <div class="media-block trigger-media-block">

            </div>

            <div class="bottom-close-btn-wrapp">
                <button type="button" class="bottom-close-lightbox trigger-bottom-close-lightbox" title="close lightbox" aria-label="close lightbox" tabindex="-1">
                    <?php esc_html_e('close lightbox', 'greyowl'); ?>
                </button>
            </div>

        </div>

    </div>
</div>
<!-- lightbox block end -->

jQuery( document ).ready(function(){
    /*************************************************************************
    * Color Picker
    *************************************************************************/
    jQuery('input.trigger-gol-colorpic').wpColorPicker();

});

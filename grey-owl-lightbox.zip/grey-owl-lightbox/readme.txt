=== Advanced Gutenberg Blocks ===
Contributors: greyowl0015
Tags: lightbox, lightbox image, lightbox gallery, wp gallery, wordpress gallery, gutenberg gallery, lightbox video, lightbox content html, lightbox ajax, ajax
Requires at least: 4.5
Tested up to: 5.1
Stable tag: 1.1.0
License: GPL-2.0
License URI: http://www.gnu.org/licenses/gpl-2.0.html

This plugin is designed to display different content in the lightbox. For example, as: image, galleries, videos and other html content. In this plug-in takde there are javascript events to control the lightbox via the .js file.

== Description ==

At the core of the plugin is the js library, which works with jQuery, each developer can use events for more features of this plugin. A list and examples of all events are on the documentation page.

== Installation ==

1. Upload the plugin files to the "/wp-content/plugins" directory, or install the plugin through the WordPress plugins screen directly.
2. Activate the plugin through the "Plugins" screen in WordPress.
3. Go to the settings of the plugin, located in the menu "Tools > Grey Owl Lightbox"

== Screenshots ==

== Changelog ==

= 1.1.0 (22/02/2019) =
* First release

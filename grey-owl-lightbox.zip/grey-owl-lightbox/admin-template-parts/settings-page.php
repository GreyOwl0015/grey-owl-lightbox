<?php

do_action('goi_page_setting');
